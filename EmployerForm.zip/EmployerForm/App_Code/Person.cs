﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Person
/// </summary>
public class Person
{
    public int personID;
    public String firstName;
    public String fastName;
    public String email;
    public int AddressID;
    public String personType;


    public Person()
    {
    }
}